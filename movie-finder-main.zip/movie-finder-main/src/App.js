import React from 'react';
import './App.css';
import Movies from './components/movie/index';


// function App() {
//   return (
//     <div className="App">
      
//     </div>
//   );
// }

function App() {
  return <Movies />;
}
export default App;
